import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class Payment {

  private baseUrl = 'http://localhost:8080/api/patient/payment';

  constructor(private http: HttpClient) {}

  // Existing
  processPayment(data: any) {
    return this.http.post(`${this.baseUrl}/process`, data, {
      responseType: 'text',
    });
  }

  // 🔹 ADMIN
  getAllPayments() {
    return this.http.get<any[]>(`${this.baseUrl}/all`);
  }

  // 🔹 PATIENT
  getPaymentsByUsername(username: string) {
    return this.http.get<any[]>(
      `${this.baseUrl}/user/${username}`
    );
  }
}