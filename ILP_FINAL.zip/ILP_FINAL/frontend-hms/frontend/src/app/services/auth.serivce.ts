import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
    login(role: 'PATIENT' | 'ADMIN' | 'DOCTOR') {
  const expiry = Date.now() + (30 * 60 * 1000); // 30 minutes

  localStorage.setItem('loggedIn', 'true');
  localStorage.setItem('role', role);
  localStorage.setItem('loginExpiry', expiry.toString());
}

    logout(){
      localStorage.clear();
    }

    isLoggedIn(): boolean {
  const loggedIn = localStorage.getItem('loggedIn') === 'true';
  const expiry = localStorage.getItem('loginExpiry');

  if (!loggedIn || !expiry) {
    return false;
  }

  // expired
  if (Date.now() > Number(expiry)) {
    localStorage.clear();
    return false;
  }

  return true;
}
    getRole():string|null{
      return localStorage.getItem('role');
    }
    
}

