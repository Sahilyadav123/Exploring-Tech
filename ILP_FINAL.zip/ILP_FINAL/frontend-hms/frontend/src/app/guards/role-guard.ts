import { CanActivateFn,Router } from '@angular/router';
import {inject} from '@angular/core';
import { AuthService } from '../services/auth.serivce';

export const roleGuard = (expectedRole:string):
  CanActivateFn=>{
    return ()=>{
      const auth=inject(AuthService);
      const router=inject(Router);
      if(auth.getRole()===expectedRole){
        return true;
      }
      router.navigate(['/']);
      return false;
    };
};
