import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Payment } from '../../services/payment';

@Component({
  selector: 'app-patient-payments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payments-list.html',
  styleUrls: ['./payments-list.css']
})
export class PatientPaymentsComponent implements OnInit {

  payments: any[] = [];
  isLoading = true;

  constructor(
    private paymentService: Payment,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const username = localStorage.getItem('username');

    if (!username) {
      console.error('Username not found in localStorage');
      this.isLoading = false;
      return;
    }

    this.paymentService.getPaymentsByUsername(username).subscribe({
      next: (res) => {
        this.payments = res || [];
        this.isLoading = false;
        this.cdr.detectChanges(); // 🔥 ensures render
      },
      error: (err) => {
        console.error(err);
        this.isLoading = false;
      }
    });
  }
}