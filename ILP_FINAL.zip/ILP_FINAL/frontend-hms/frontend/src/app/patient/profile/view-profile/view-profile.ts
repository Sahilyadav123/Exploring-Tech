import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Patient } from '../../../services/patient';
import { AlertService } from '../../../shared/alert.service';

@Component({
  selector: 'app-view-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-profile.html',
  styleUrls: ['./view-profile.css']
})
export class ViewProfile implements OnInit {

  patient: any = {};
  username = '';

  constructor(private router: Router, private patientService: Patient, private alertService: AlertService) {
    this.username = localStorage.getItem('username') || '';
  }

  ngOnInit() {
    this.loadProfile();
  }

  loadProfile() {
    this.patientService.getProfile(this.username).subscribe({
      next: (res: any) => {
        this.patient = res;
      },
      error: () => this.alertService.showAlert('Error loading profile', 'error')
    });
  }

  editProfile() {
    this.router.navigate(['/patient/profile/edit']);
  }
  
  deleteProfile() {
    if (confirm('Are you sure you want to delete your profile?')) {
      this.patientService.deleteProfile(this.username).subscribe({
        next: (res: string) => {
          if (res === 'DELETED') {
            localStorage.clear();
            this.router.navigate(['/']);
          } else {
            this.alertService.showAlert('Error deleting profile', 'error');
          }
        },
        error: () => this.alertService.showAlert('Server error', 'error')
      });
    }
  }
}