import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-profile.html',
  styleUrls: ['./edit-profile.css']
})
export class EditProfile {

  patient = {
    name: '',
    email: '',
    phone: ''
  };

  constructor(private router: Router) {
    // First time dummy → else from localStorage
    this.patient.name = localStorage.getItem('name') || 'Sahil Yadav';
    this.patient.email = localStorage.getItem('email') || 'sahil@gmail.com';
    this.patient.phone = localStorage.getItem('phone') || '9876543210';
  }

  save() {
    localStorage.setItem('name', this.patient.name);
    localStorage.setItem('email', this.patient.email);
    localStorage.setItem('phone', this.patient.phone);

    this.router.navigate(['/patient/profile/view']);
  }
}