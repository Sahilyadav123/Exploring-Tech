import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';
import { Router } from '@angular/router';
import { Payment as PaymentService } from '../../services/payment';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css']
})
export class Payment implements OnInit {

  paymentForm: FormGroup;
  consultationFee = 500;
  appointment: any = {};

  // ✅ Frontend-allowed cards only
  validCards = {
    VISA: {
      cardName: 'Demo Visa User',
      cardNumber: '4111111111111111',
      expiry: '2026-12',
      cvv: '123'
    },
    MASTERCARD: {
      cardName: 'Demo Master User',
      cardNumber: '5555555555552222',
      expiry: '2027-06',
      cvv: '456'
    }
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private paymentService: PaymentService,
    private alertService: AlertService
  ) {
    this.paymentForm = this.fb.group({
      cardName: ['', Validators.required],
      cardNumber: [
        '',
        [Validators.required, Validators.pattern('^[0-9]{16}$')]
      ],
      expiry: ['', Validators.required],
      cvv: [
        '',
        [Validators.required, Validators.pattern('^[0-9]{3}$')]
      ]
    });
  }

  ngOnInit(): void {
    this.appointment = history.state.appointment || {};
  }

  // ✅ Auto-fill on hover
  fillCard(type: 'VISA' | 'MASTERCARD'): void {
    const card = this.validCards[type];

    this.paymentForm.setValue({
      cardName: card.cardName,
      cardNumber: card.cardNumber,
      expiry: card.expiry,
      cvv: card.cvv
    });
  }

  // ✅ Pay Now with frontend-only validation
  payNow(): void {
    if (this.paymentForm.invalid) {
      this.alertService.showAlert('Invalid card details', 'error');
      return;
    }

    const enteredCard = this.paymentForm.value;

    const isValidCard = Object.values(this.validCards).some(
      card =>
        card.cardNumber === enteredCard.cardNumber &&
        card.cvv === enteredCard.cvv &&
        card.expiry === enteredCard.expiry
    );

    if (!isValidCard) {
      this.alertService.showAlert('This card is not supported', 'error');
      return;
    }

    const paymentData = {
      username: this.appointment.username,
      appointmentId: this.appointment.id,
      amount: this.consultationFee,
      status: 'pending',
      date: new Date().toISOString().split('T')[0]
    };

    this.paymentService.processPayment(paymentData).subscribe({
      next: (res: string) => {
        if (res === 'PAYMENT_SUCCESS') {
          this.alertService.showAlert('Booking successful!', 'success');

          setTimeout(() => {
            this.router.navigate(
              ['/patient/payment-success'],
              { state: { appointment: this.appointment } }
            );
          }, 1500);
        } else {
          this.alertService.showAlert('Payment failed', 'error');
        }
      },
      error: () => {
        this.alertService.showAlert('Server error', 'error');
      }
    });
  }

  resetForm(): void {
    this.paymentForm.reset();
  }
}