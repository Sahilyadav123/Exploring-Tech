import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Admin } from '../../services/admin';
import { AlertService } from '../../shared/alert.service';

@Component({
  selector: 'app-manage-complaints',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manage-complaints.html',
  styleUrls: ['./manage-complaints.css']
})
export class ManageComplaints implements OnInit {

  complaints: any[] = [];

  constructor(private adminService: Admin, private alertService: AlertService) {}

  ngOnInit() {
    this.loadComplaints();
  }

  loadComplaints() {
    this.adminService.getAllComplaints().subscribe({
      next: (res: any) => {
        this.complaints = res;
      },
      error: () => this.alertService.showAlert('Error loading complaints', 'error')
    });
  }

  updateStatus(complaint: any, newStatus: string) {
    this.adminService.updateComplaintStatus(complaint.id, newStatus).subscribe({
      next: (res: string) => {
        if (res === 'UPDATED') {
          complaint.status = newStatus;
        } else {
          this.alertService.showAlert('Error updating status', 'error');
        }
      },
      error: () => this.alertService.showAlert('Server error', 'error')
    });
  }
}