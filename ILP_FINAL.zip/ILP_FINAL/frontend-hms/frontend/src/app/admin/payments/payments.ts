import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Payment } from '../../services/payment';

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payments.html',
  styleUrl:'./payments.css',
})
export class PaymentsComponent implements OnInit {

  payments: any[] = [];
  paginatedPayments: any[] = [];

  pageSize = 5;
  currentPage = 1;

  constructor(
    private paymentService: Payment,
    private cdr: ChangeDetectorRef   // 👈 IMPORTANT
  ) {}

  ngOnInit(): void {
    this.paymentService.getAllPayments().subscribe({
      next: (res) => {
        console.log('API RESPONSE', res);

        this.payments = res ?? [];
        this.updatePagination();

        this.cdr.detectChanges();   // 🔥 FORCE UI UPDATE
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  updatePagination() {
    const start = (this.currentPage - 1) * this.pageSize;
    this.paginatedPayments = this.payments.slice(start, start + this.pageSize);
  }
}