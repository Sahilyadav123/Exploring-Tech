INSERT INTO admin (username, password) VALUES ('admin', 'admin123');
INSERT INTO doctors (doctor_id, username, password, name, specialization, qualification, experience, availability) VALUES ('doctor1', 'doctor1', 'pass', 'Dr. Smith', 'Cardiology', 'MD', 5, 'Monday to Friday');
INSERT INTO doctors (doctor_id, username, password, name, specialization, qualification, experience, availability) VALUES ('doctor2', 'doctor2', 'pass', 'Dr. Johnson', 'Neurology', 'MD', 10, 'Monday to Saturday');

INSERT INTO payments (username, appointment_id, amount, status, date) VALUES
('rahul', 1001, 500.00, 'SUCCESS', CURRENT_TIMESTAMP()),
('priya', 1002, 750.00, 'PENDING', DATEADD('DAY', -1, CURRENT_TIMESTAMP())),
('aman', 1003, 1200.00, 'FAILED', DATEADD('DAY', -2, CURRENT_TIMESTAMP())),
('neha', 1004, 650.00, 'SUCCESS', DATEADD('DAY', -3, CURRENT_TIMESTAMP())),
('rohit', 1005, 900.00, 'SUCCESS', DATEADD('DAY', -4, CURRENT_TIMESTAMP())),
('simran', 1006, 1100.00, 'PENDING', DATEADD('DAY', -5, CURRENT_TIMESTAMP()));