package com.example.HMS.patient.payment;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "payments")
public class PaymentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String appointmentId;
    private double amount;
    @Column(columnDefinition = "VARCHAR(255) DEFAULT 'pending'")
    private String status;
    private String date;

    public PaymentEntity() {
    }

    public PaymentEntity(String username, double amount, String status, String date) {
        this.username = username;
        // this.appointmentId = appointmentId;
        this.amount = amount;
        this.status = status;
        this.date = date;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    // 🔥 THIS METHOD WAS MISSING
    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }
}