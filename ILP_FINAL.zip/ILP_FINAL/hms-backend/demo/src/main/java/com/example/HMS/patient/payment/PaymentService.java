package com.example.HMS.patient.payment;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    private final PaymentRepository repo;

    public PaymentService(PaymentRepository repo) {
        this.repo = repo;
    }

    public String processPayment(PaymentEntity payment) {

        payment.setStatus("success");

        // FIRST save → get generated ID
        PaymentEntity savedPayment = repo.save(payment);

        // Build username/id
        String ref = savedPayment.getUsername() + "/" + savedPayment.getId();

        savedPayment.setAppointmentId(ref);

        // SECOND save → update appointmentId
        repo.save(savedPayment);

        return "PAYMENT_SUCCESS";
    }

    public List<PaymentEntity> getAllPayments() {
        return repo.findAll();
    }

    public List<PaymentEntity> getPaymentsByUsername(String username) {
        return repo.findByUsername(username);
    }
}