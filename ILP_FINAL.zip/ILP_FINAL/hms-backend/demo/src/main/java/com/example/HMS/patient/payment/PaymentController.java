package com.example.HMS.patient.payment;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/patient/payment")
@CrossOrigin(origins = "http://localhost:4200")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping("/process")
    public String process(@RequestBody PaymentEntity payment) {
        return service.processPayment(payment);
    }

    // ADMIN
    @GetMapping("/all")
    public List<PaymentEntity> getAllPayments() {
        return service.getAllPayments();
    }

    // PATIENT
    @GetMapping("/user/{username}")
    public List<PaymentEntity> getPaymentsByUsername(
            @PathVariable String username) {
        return service.getPaymentsByUsername(username);
    }
}